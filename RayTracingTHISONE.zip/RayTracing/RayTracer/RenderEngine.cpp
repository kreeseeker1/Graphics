// RenderEngine.cpp
// Renderengine is where the main ray tracing algorithm is implemented.

#include "RenderEngine.h"

//------------------------------------------------------------------  Constructors
RenderEngine::RenderEngine() : world_ptr(NULL)
{}

RenderEngine::RenderEngine(World* w_ptr)
{
    world_ptr = w_ptr;
}


RenderEngine::RenderEngine(const RenderEngine& other)
{
    world_ptr = other.world_ptr;
}

//------------------------------------------------------------------  Destructor
RenderEngine::~RenderEngine()
{}

//------------------------------------------------------------------  Operators
RenderEngine& RenderEngine::operator=(const RenderEngine& rhs)
{
    if (this == &rhs) return *this;
    world_ptr = rhs.world_ptr;
    return *this;
}

//------------------------------------------------------------------ Setter
void
RenderEngine::set_world(World* w_ptr)
{
    world_ptr = w_ptr;
}

//------------------------------------------------------------------ render_scene
// This is the main ray traing loop over pixels
void
RenderEngine::render_scene()
{
	
    Camera *camera = world_ptr->camera_ptr;
    RGBColor pixel_color;
	if(camera == NULL) {
		printf("camera is null");
	}
	else {
		printf("camera is not null");
	}

    // PART 1:
    // Loop over rows and columns of images (pixels)
        // get the ray from camera to the given pixel
        // trace the ray to get pixel_color
        // make sure color is in range (1,0)  - see max_to_one() function
        // set image pixel to this color as follows:
            //int index = row * 3 * camera->xres + col*3 ;
            //camera->image[index]   = pixel_color.r;
            //camera->image[index+1] = pixel_color.g;
            //camera->image[index+2] = pixel_color.b;

	for (int row=0; row < camera->xres; row++) { 
		for (int col=0; col < camera->yres; col++) {		
			Ray ray = camera->pixRay(row, col); //get the ray using pixRay method of Camera class

			//int index = row * 3 * camera->xres + col*3 ;
		
			pixel_color = trace_ray(ray,3); //trace the ray.
			
			pixel_color = max_to_one(pixel_color);
			int index = row * camera->xres +col * 3;
			//float temp = camera->image[index] = 0.1f;
			//printf("%f\n", camera->image[index]);
			
			//if i uncomment the below codes, it wont compile
            camera->image[index]   = pixel_color.r;
            camera->image[index+1] = pixel_color.g;
            camera->image[index+2] = pixel_color.b;
		}
	}

}

// ----------------------------------------------------------------------------- trace_ray
//  Given a ray, loop over objects in scene to determine the closest object (if any) that
//  intersects the ray.

RGBColor
RenderEngine::trace_ray(const Ray& ray, int rayDepth)
{
	
    Vector3D normal; // don't need until lighting and shading is added
    Vector3D local_hit_point;
    float	tmin 			= kHugeValue;
    int 	num_objects 	= world_ptr->objects.size();
    RGBColor pixel_color(0,0,0);

    ShadeRec sr;  // stores information about the closest object (so far) that has been it. Look at sphere.cpp to see what is stored.
    sr.hit_an_object = false; //init

    // PART 1:  JUST NEED TO IMPLEMENT THE LOOP OVER OBJECTS:
    // loop over objects in the scene
    // For each object, check to see if the ray intersects it:
            // ShadeRec srObject = world_ptr->objects[j]->hit(ray);
            // if this is closer than anything else previously seen, update tmin, and sr
            // set pixel color:
            //        pixel_color = world_ptr->objects[j]->color; // only used until lights and materials are implemented

	for(int i = 0; i < num_objects; i++) { //loop thru objects array, array of object can be obtained by doing world_ptr->objects
		sr = world_ptr->objects[i]->hit(ray);	//how i return the ShadeRec
		if(sr.hit_an_object) {
			tmin = sr.t; //from Shawn
			pixel_color = world_ptr->objects[i]->color;
		}
		
	}
	


    if (sr.hit_an_object)
    {
        // PART 2:
        //    Need to implement calc_shade
        //    pixel_color =  calc_shade(ray, sr);
        // PART 3:   need to implement reflected color here
    }
    else
    {
        pixel_color = world_ptr->background_color;
    }
	/*
	printf("showing value from trace_ray method");
	printf("%d\n", pixel_color.r);
	printf("%d\n", pixel_color.g);
	printf("%d\n", pixel_color.b);
	*/
    return pixel_color;

}

//------------------------------------------------------------------ calc shading

RGBColor
RenderEngine::calc_shade(const Ray& ray, ShadeRec& sr)
{
    RGBColor pixel_color(0,0,0);
    Material *m_ptr =  sr.material_ptr;
   // int num_lights = world_ptr->lights.size();

   // will need to loop over lights

       // RGBColor ambient = m_ptr->ka * m_ptr->ca * light.intensity * light.color;
       // pixel_color 	+=  ambient;

        //NEED TO IMPLEMENT:
        // Check if in shadow
        // if not
        //      calcualte the light direction
        //      calculate the camera direction
        //      check to see if viewer and/or camera are below surface
        //      if not
        //          Calculate diffuse light
        //          calculate  reflection direction
        //          Calculate specular light
        //      return accumation  of ambient, diffuse, specular
    // end loop over lights

    return pixel_color;
}

// ----------------------------------------------------------------------------- calculate reflected color

RGBColor
RenderEngine::calc_reflected(const Ray& ray, ShadeRec& sr, int rayDepth)
{
    RGBColor reflected_color;

    //  PART 3:  NEED TO IMPLEMENT REFLECTION VIA RECURSION
    //   first calculate the direction of the reflected ray (not the same as the reflection direction in calc_shade!)
    //   then recurse on this direction

    return reflected_color;

}

// ----------------------------------------------------------------------------- check for shadows

// PART 3:
//bool
//RenderE/ngine::inShadow(Vector3D hit_point, PointLight* light) const


// ------------------------------------------------------------------ clamp

RGBColor
RenderEngine::max_to_one(const RGBColor& c) const
{
    float max_value = max(c.r, max(c.g, c.b));

    if (max_value > 1.0)
        return (c / max_value);
    else
        return (c);
}

// ------------------------------------------------------------------ clamp_to_color
// Set color to red if any component is greater than one

RGBColor
RenderEngine::clamp_to_color(const RGBColor& raw_color) const
{
    RGBColor c(raw_color);

    if (raw_color.r > 1.0 || raw_color.g > 1.0 || raw_color.b > 1.0)
    {
        c.r = 1.0;
        c.g = 0.0;
        c.b = 0.0;
    }

    return (c);
}


