// Contains the implementation of the member functions in Camera.h

#include "Camera.h"

Camera::Camera()
	:  	loc(0,0,0),
        u(1,0,0),
        v(0,1,0),
        n(0,0,1),
        d(10),
        w(4),
        h(3),
        xres(640),
		yres(480)
{
   image = new GLfloat[ xres*yres*3];
}

Camera::Camera(int xr, int yr)
	:  	loc(0,0,0),
        u(1,0,0),
        v(0,1,0),
        n(0,0,1),
        d(10),
        w(4),
        h(3),
        xres(xr),
		yres(yr)
{
    image = new GLfloat[ xres*yres*3];
}


Camera::~Camera()
{
    delete[] image;
}

Camera::Camera(const Camera& cam)
	:  	loc(cam.loc),
        u(cam.u),
        v(cam.v),
        n(cam.n),
        d(cam.d),
        w(cam.w),
        h(cam.h),
        xres(cam.xres),
		yres(cam.yres)
{
    image = new GLfloat[ xres*yres*3];
}

Camera& Camera::operator=(const Camera& rhs)
{
    if (this == &rhs) return *this; // handle self assignment

    loc				= rhs.loc;
	u				= rhs.u;
	v				= rhs.v;
	n				= rhs.n;
	d				= rhs.d;
	w				= rhs.w;
	h				= rhs.h;
	xres			= rhs.xres;
	yres			= rhs.yres;
    return *this;
}

//------------------------  Calculate the camera coordinate basis vectors
void
Camera::calcUVN(Vector3D VPN, Vector3D VUP) {
     // ************************  NEED TO CALCULATE u, v, n

	//divisor for n
	double n_divisor = VPN.length();
	
	n = VPN/n_divisor;
	//divisor for u
	double u_divisor = ((Vector3D)(VUP * VPN)).length();
	u = (VUP * VPN) / u_divisor;

	v = n * u;
}

//------------------------  Calculate the ray from camera to pixel (i,j) on viewscreen
Ray
Camera::pixRay(int i, int j) const {
     Vector3D dir;
	 
    float a = -w/2 + w*i/(xres-1.);
     float b = -h/2 + h*j/(yres-1.);
     dir = a*u + b*v - d*n;
	 

	 /*
	 Vector3D P1((double)i,(double)j, 1.0);
	 Vector3D camera;

	 Vector3D Pf = camera - P1;

	 double magnitude = Pf.length();
	 dir = Pf/magnitude;
	 */
     Ray r(loc,dir);
     return r;
}
